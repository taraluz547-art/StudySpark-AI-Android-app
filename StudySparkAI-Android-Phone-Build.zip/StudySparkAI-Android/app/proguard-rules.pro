# No custom ProGuard rules are required for the initial wrapper build.
